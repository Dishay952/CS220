# Assignment 4 CS220

### Aryan Vora 200204, Dishay Mehta 200341, Tejas R 201050

## Question 1: 3-bit Gray Counter

> 'A4Q1_GrayCounter.v' is the implementation of a 3-bit Gray Counter.
> <br>
> We have implemented the above as a Mealy Machine. It outputs 1 as transition occurs from S7 to S0 otherwise it outputs 0.
> <br>
> 'A4Q1_GrayCounter_tb.v' is the testbench with 18 clock cycles.
> <br>
> 'A4Q1_CS220_doc.pdf' is the detailed description and documentation of the 3-bit Gray Counter.

## Question 2: 8-bit Adder/Subtractor

> 'A4Q2_EightBitAdderSubtractor.v' is the implementation of a 8-bit Adder/Subtractor.
> <br>
> 'A4Q2_OneBitAdderSubtractor.v' is the implementation of a 1-bit Adder/Subtractor.
> <br>
> 'A4Q2_EightBitAdderSubtractor_tb.v' is the testbench with 20 inputs.
> <br>
> 'A4Q2_CS220_doc.pdf' is the detailed description and documentation of the 8-bit Adder/Subtractor.