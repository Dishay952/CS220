# Assignment 5 CS220

### Aryan Vora 200204, Dishay Mehta 200341, Tejas R 201050

## Question 1: 8-bit GCD

> 'A5Q1_GCD.v' is the implementation of a 8-bit GCD Calculator.
> <br>
> 'A5Q1_GCD_tb.v' is the testbench with 18 clock cycles.
> <br>

## Question 2: Insertion Sort

> 'A5Q2_InsertionSort.s' is the implementation of the Insertion Sort algorithm in MIPS.
> <br>

## Question 3: Fibonacci Numbers

> 'A5Q3_Fibonacci.s' is the implementation to generate Fibonacci Numbers in MIPS.
> <br>

## Question 4: Vector Summation

> 'A5Q4_Vector.s' is the implementation of Question 4 in MIPS.
> <br>